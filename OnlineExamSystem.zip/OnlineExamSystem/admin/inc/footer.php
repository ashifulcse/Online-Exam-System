 </section>
<section class="footeroption">
		<h6>&copy;2021&nbsp;&nbsp;&nbsp;INNOVAT PARK</h6>
	</section>
</div>
</body>
</html>